git ls-files --exclude-standard -o -i
